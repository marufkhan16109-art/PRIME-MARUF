cat > script.js << 'EOF'
// Matrix Rain
const canvas = document.getElementById("matrix");
const ctx = canvas.getContext("2d");

let width, height;
const chars = "01アイウエオ1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let fontSize = 16;
let columns, drops = [];

function resizeCanvas() {
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = width;
  canvas.height = height;
  columns = Math.floor(width / fontSize);
  drops = Array(columns).fill(1);
}

function drawMatrix() {
  ctx.fillStyle = "rgba(5, 8, 12, 0.1)";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "#00f7ff";
  ctx.font = `${fontSize}px monospace`;

  for (let i = 0; i < drops.length; i++) {
    const text = chars[Math.floor(Math.random() * chars.length)];
    ctx.fillText(text, i * fontSize, drops[i] * fontSize);

    if (drops[i] * fontSize > height && Math.random() > 0.975) drops[i] = 0;
    drops[i]++;
  }
}

window.addEventListener("resize", resizeCanvas);
resizeCanvas();
setInterval(drawMatrix, 35);

// Music Control
const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");

musicBtn.addEventListener("click", () => {
  if (music.paused) {
    music.play().catch(() => {
      alert("song.mp3 ফাইলটি prime-maruf ফোল্ডারে রাখো!");
    });
    musicBtn.textContent = "Ⅱ PAUSE MUSIC";
  } else {
    music.pause();
    musicBtn.textContent = "▶ PLAY HACKER MUSIC";
  }
});

// Loader
window.addEventListener("load", () => {
  setTimeout(() => {
    document.getElementById("loader").classList.add("hidden");
  }, 1200);
});
EOF
